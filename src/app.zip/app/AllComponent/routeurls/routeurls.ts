export const routeurls = Object.freeze({
  BASE_API_URL: 'http://18.139.163.118:5022',//'http://18.139.163.118:5022',//'http://192.168.0.107:5022',//'http://18.136.57.177:5022',//'http://103.218.25.96:5021',//'http://localhost:8086'
  EVENT_DAY__ADD_URL: '/api/eventDay',
  EVENT_DAY_GET_Y_ID: '/api/eventDay/getbyid',
  LOGIN_API_BASE_URL: "/api/login",
  COURSE_DAY__ADD_URL: '/api/course',
  TEMPLATE_ADD_URL: '/api/template',
  USER_ADD_URL: '/api/user',
  SCHOOL_ADD_URL: '/api/school',
  FOREIGN_COURSE_URL: '/api/foreignCourse'
  //... more of your variable
});
