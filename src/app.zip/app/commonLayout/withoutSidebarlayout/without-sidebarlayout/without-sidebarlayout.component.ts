import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-without-sidebarlayout',
  templateUrl: './without-sidebarlayout.component.html',
  styleUrls: ['./without-sidebarlayout.component.scss']
})
export class WithoutSidebarlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
