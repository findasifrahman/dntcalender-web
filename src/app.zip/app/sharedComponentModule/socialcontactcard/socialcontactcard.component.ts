import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socialcontactcard',
  templateUrl: './socialcontactcard.component.html',
  styleUrls: ['./socialcontactcard.component.css']
})
export class SocialcontactcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
